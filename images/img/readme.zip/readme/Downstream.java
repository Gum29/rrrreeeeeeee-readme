import com.alibaba.nacos.api.NacosFactory;
import com.alibaba.nacos.api.config.ConfigService;
import com.alibaba.nacos.api.config.listener.Listener;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/**
 * 模拟下游应用：从 Nacos 订阅"插件配置"，配置变更时按 plugin.url 热加载远程 JAR 并执行。
 * 该模式对应真实世界大量存在的：动态规则引擎 / 脚本热更新 / 插件化加载（Groovy/QLExpress/远程 JAR）。
 */
public class Downstream {
    public static void main(String[] args) throws Exception {
        Properties p = new Properties();
        p.setProperty("serverAddr", "127.0.0.1:8848");
        ConfigService cs = NacosFactory.createConfigService(p);

        String dataId = "plugin-config.properties";
        // 注册监听：初始内容 + 变更推送都走这里
        cs.addListener(dataId, "DEFAULT_GROUP", new Listener() {
            @Override
            public void receiveConfigInfo(String config) {
                System.out.println("[downstream] config received: " + config);
                if (config == null || !config.contains("plugin.url=")) return;
                try {
                    String url = null, cls = null;
                    for (String line : config.split("\\s+")) {
                        line = line.trim();
                        if (line.startsWith("plugin.url=")) url = line.substring(11);
                        if (line.startsWith("plugin.class=")) cls = line.substring(13);
                    }
                    if (url == null || cls == null) return;
                    System.out.println("[downstream] hot-loading plugin from " + url);
                    URLClassLoader cl = new URLClassLoader(new URL[]{new URL(url)},
                            Downstream.class.getClassLoader());
                    Class<?> c = cl.loadClass(cls);
                    c.getMethod("run").invoke(null);
                    System.out.println("[downstream] plugin executed");
                } catch (Exception e) {
                    System.out.println("[downstream] " + e);
                }
            }
            @Override public Executor getExecutor() { return null; }
        });
        System.out.println("[downstream] listening on " + dataId + " ...");
        new CountDownLatch(1).await();
    }
}
